# scm
A final year project on supply chain management for bakery products.